<script>
    //fetching current page name
    const urlPathname = window.location.pathname.split('/');
    const currentPage = urlPathname[urlPathname.length - 1] != 'chit' ? urlPathname[urlPathname.length - 1] : 'null';
    // localStorage.setItem('currentPage', 'home.php');
</script>

<!-- Required jQuery first, then Bootstrap Bundle JS -->
<script src="jsd/jquery.min.js"></script>
<script src="jsd/bootstrap.bundle.min.js"></script>
<script src="jsd/moment.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
<!-- <script src="vendor/cdn_jquery/jquery-3.7.1.min.map"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>

<!-- Slimscroll JS -->
<script src="vendor/slimscroll/slimscroll.min.js"></script>
<script src="vendor/slimscroll/custom-scrollbar.js"></script>

<script src="jsd/main.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.7/dist/sweetalert2.all.min.js"></script>

<script type="text/javascript" src="jsd/datatables.min.js"></script>
<!-- <script type="text/javascript" language="javascript"></script> -->

<!-- Slimscroll JS -->
<script src="vendor/slimscroll/slimscroll.min.js"></script>
<script src="vendor/slimscroll/custom-scrollbar.js"></script>

<!-- Multi select Plugin -->
<script src="vendor/multiselect/public/assets/scripts/choices.min.js"></script>

<!-- Google Charts -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>



