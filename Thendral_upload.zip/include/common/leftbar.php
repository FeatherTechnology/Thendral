
<link rel="stylesheet" href="css/leftbar.css">
<!-- Sidebar wrapper start -->
<nav id="sidebar" class="sidebar-wrapper" style="background-color:var(--primary-color);">
<!-- <nav id="sidebar" class="sidebar-wrapper" style="background-color:red"> -->

	<!-- Sidebar brand start  -->
	<div class="sidebar-brand" style="background-color: var(--primary-color)">
		<a href="#" class="logo">
			<h2  style="color: white">THENDRAL</h2>
		</a>
	</div>

	<div class="sidebar-content">
		<!-- sidebar menu start -->
		<div class="sidebar-menu">
		</div>
		<!-- sidebar menu end -->
	</div>
</nav>
<!-- Sidebar wrapper end -->
