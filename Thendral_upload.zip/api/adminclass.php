<?php
class admin
{
}//Class End
