<?php

include('config-file.php');
include("adminclass.php");
include("../ajaxconfig.php");

$userObj = new admin();
