<?php
$HOSTPATH = "https://" . $_SERVER['HTTP_HOST'] . "/thendral/";

define('HOSTPATH', $HOSTPATH);
