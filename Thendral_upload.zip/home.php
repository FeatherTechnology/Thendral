<!DOCTYPE html>
<html lang="en">

<head>
	<?php include "include/common/dashboardhead.php"; ?>
</head>

<body>
	<?php include "include/common/body.php"; ?>

	<footer>
		<?php include "include/common/dashboardfooter.php" ?>
		<script src="jsd/leftbar.js"></script>
		<script src="jsd/body.js"></script>
	</footer>

</body>